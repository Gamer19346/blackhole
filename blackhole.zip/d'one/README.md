# Black Hole Simulation with Gravitational Lensing

## Project Overview
This project implements a realistic 3D black hole simulation with gravitational lensing effects using Three.js. The application features an interactive environment where users can observe and interact with a physically-inspired representation of a black hole given the following rules and statements you have set.

## Features
- Realistic black hole visualization with accretion disk
- Gravitational lensing effect simulation
- Interactive camera controls (rotate, pan, zoom)
- Dynamic skybox environment
- Responsive design (mostly)
- Performance-optimized rendering (turning off anti-aliasing really helped.)

## Technical Implementation
- Built with Three.js for 3D rendering
- Custom shader implementation for gravitational lensing
- Post-processing effects using EffectComposer
- Optimized performance through efficient rendering techniques

## Setup Instructions
1. Clone the repository
2. Ensure all dependencies are installed:
   ```bash
   npm install three
3. Place required texture files in the project root:

space.jpg (skybox texture)
accretion_disk.jpg (disk texture)

4. Start a local server to run the application

**Usage**

- hold and drag left-click to rotate the view
- Scroll to zoom in/out
- Double-click to reset camera position
- Hold right-click to Pan


**Performance Considerations**


- Optimized shader calculations
- Efficient texture handling
- Balanced visual quality and performance

**Dependencies**

Three.js
GSAP (for animations)
Web browser with WebGL support



i really didn't know how blackholes worked so i just made something up and tried my best.

i have also marked each place and said what is does.
i really hope if was atleast acceptable considering the time i put in into it. Thanks :)
Members: One (@Raidiantatos)