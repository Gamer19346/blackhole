// main.js
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { LensingEffect } from './distort.js';
import { GravitationalLens } from './gravitationalLens.js';

// Primary scene configuration
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: false });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Environment setup with space background
const textureLoader = new THREE.TextureLoader();
const spaceTexture = textureLoader.load('textures/space.jpg', (texture) => {
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
});

// Skybox implementation
const skyboxGeometry = new THREE.SphereGeometry(500, 64, 64);
const skyboxMaterial = new THREE.MeshBasicMaterial({
    map: spaceTexture,
    side: THREE.BackSide
});
const skybox = new THREE.Mesh(skyboxGeometry, skyboxMaterial);
scene.add(skybox);

// Black hole system initialization
const gravLens = new GravitationalLens(2.0);
scene.add(gravLens.getMesh());

// Camera control system setup
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.screenSpacePanning = false;
controls.minDistance = 8;
controls.maxDistance = 26;
controls.maxPolarAngle = Math.PI * 0.8;
controls.minPolarAngle = Math.PI * 0.2;

// Camera reset functionality
renderer.domElement.addEventListener('dblclick', () => {
    gsap.to(camera.position, {
        duration: 1,
        x: 0,
        y: 0,
        z: 10,
        ease: 'power2.inOut'
    });
    gsap.to(controls.target, {
        duration: 1,
        x: 0,
        y: 0,
        z: 0,
        ease: 'power2.inOut',
        onUpdate: () => controls.update()
    });
});

// Render target setup
const renderTarget = new THREE.WebGLRenderTarget(window.innerWidth, window.innerHeight);

// Post-processing configuration
const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
composer.addPass(renderPass);

// Lensing effect implementation
const lensingEffect = new LensingEffect(2.0);
lensingEffect.setRadius(0.15);
const lensingPass = new ShaderPass(lensingEffect.material);
lensingPass.renderToScreen = true;
composer.addPass(lensingPass);

// Initial camera positioning
camera.position.z = 10;

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    controls.update();
    gravLens.update(camera);
    lensingEffect.updateBlackHolePosition(gravLens.getMesh().position, camera);
    skybox.position.copy(camera.position);
    composer.render();
}

// Window resize handling
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    composer.setSize(window.innerWidth, window.innerHeight);
    lensingEffect.updateAspectRatio(window.innerWidth, window.innerHeight);
});

animate();
