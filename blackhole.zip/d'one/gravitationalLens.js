// gravitationalLens.js
import * as THREE from 'three';

class GravitationalLens {
    constructor(radius = 2.0) {
        // Storing the base radius for scaling calculations
        this.radius = radius;
        
        // Setting up the primary black hole geometry and material
        const blackHoleGeometry = new THREE.SphereGeometry(radius * 2.5, 32, 32);
        const blackHoleMaterial = new THREE.MeshBasicMaterial({ 
            color: 0x000000,
            transparent: false,
            side: THREE.DoubleSide,
            depthWrite: true,
            depthTest: true
        });
        this.blackHole = new THREE.Mesh(blackHoleGeometry, blackHoleMaterial);

        // Initializing the accretion disk system
        this.accretionDiskGroup = new THREE.Group();
        const diskLayers = 20;
        const diskTexture = new THREE.TextureLoader().load('textures/accretion_disk.jpg');
        
        // Creating multiple disk layers for depth and visual complexity
        for(let i = 0; i < diskLayers; i++) {
            const layerRadius = radius * (1.5 + i * 0.12);
            const diskGeometry = new THREE.RingGeometry(
                layerRadius,
                layerRadius + radius * 0.25,
                64
            );
            
            // Setting up shader material for dynamic disk effects
            const diskMaterial = new THREE.ShaderMaterial({
                uniforms: {
                    diskTexture: { value: diskTexture },
                    time: { value: 0 },
                    radius: { value: radius },
                    layerOffset: { value: i / diskLayers },
                    totalLayers: { value: diskLayers }
                },
                vertexShader: `
                    varying vec2 vUv;
                    varying float vLayerFactor;
                    uniform float layerOffset;
                    uniform float totalLayers;
                    
                    void main() {
                        vUv = uv;
                        vLayerFactor = layerOffset;
                        vec3 pos = position;
                        float verticalOffset = sin(layerOffset * 3.14159) * 0.3;
                        pos.y += verticalOffset;
                        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
                    }
                `,
                fragmentShader: `
                    uniform sampler2D diskTexture;
                    uniform float time;
                    uniform float radius;
                    uniform float layerOffset;
                    varying vec2 vUv;
                    varying float vLayerFactor;

                    void main() {
                        vec2 centeredUv = vUv * 2.0 - 1.0;
                        float angle = atan(centeredUv.y, centeredUv.x);
                        float dist = length(centeredUv);
                        float rotationSpeed = (1.0 / dist) * time * (0.15 + vLayerFactor * 0.08);
                        float newAngle = angle + rotationSpeed;
                        vec2 rotatedUv = vec2(
                            cos(newAngle) * dist * 0.5 + 0.5,
                            sin(newAngle) * dist * 0.5 + 0.5
                        );
                        vec4 color = texture2D(diskTexture, rotatedUv);
                        vec3 layerColor = mix(
                            vec3(1.0, 0.3, 0.0),
                            vec3(1.0, 0.9, 0.2),
                            vLayerFactor
                        );
                        float glow = 1.0 - smoothstep(0.0, 0.8, dist);
                        vec3 glowColor = layerColor * glow * 2.0;
                        float alpha = mix(1.0, 0.6, vLayerFactor * 0.7);
                        vec3 finalColor = color.rgb * layerColor * 1.5 + glowColor;
                        gl_FragColor = vec4(finalColor, color.a * alpha);
                    }
                `,
                side: THREE.DoubleSide,
                transparent: true,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            });

            // Applying rotational variations to each disk layer
            const diskLayer = new THREE.Mesh(diskGeometry, diskMaterial);
            diskLayer.rotation.x = Math.PI / 4 + (i * 0.03);
            diskLayer.rotation.z = i * 0.015;
            this.accretionDiskGroup.add(diskLayer);
        }

        // Assembling the complete black hole system
        this.container = new THREE.Group();
        this.container.add(this.blackHole);
        this.container.add(this.accretionDiskGroup);
    }

    // Handling animation updates
    update(camera) {
        const time = performance.now() * 0.001;
        this.accretionDiskGroup.children.forEach(layer => {
            layer.material.uniforms.time.value = time;
        });
    }

    // Managing size adjustments
    setSize(size) {
        this.blackHole.scale.setScalar(size);
        this.accretionDiskGroup.scale.setScalar(size);
    }

    // Providing access to the complete mesh
    getMesh() {
        return this.container;
    }
}

export { GravitationalLens };
