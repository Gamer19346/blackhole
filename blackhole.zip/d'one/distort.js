// distort.js
import * as THREE from 'three';

class LensingEffect {
    constructor(strength = 1.0) {
        // Initializing core distortion parameters
        this.strength = strength;
        
        // Setting up uniform values for shader calculations
        this.uniforms = {
            tDiffuse: { value: null },
            blackHolePosition: { value: new THREE.Vector2(0.5, 0.5) },
            strength: { value: this.strength },
            aspectRatio: { value: window.innerWidth / window.innerHeight },
            radius: { value: 0.15 },
            distanceScale: { value: 1.0 }
        };

        // Standard vertex shader implementation
        this.vertexShader = /* glsl */`
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        // Primary distortion logic in fragment shader
        this.fragmentShader = /* glsl */`
            uniform sampler2D tDiffuse;
            uniform vec2 blackHolePosition;
            uniform float strength;
            uniform float aspectRatio;
            uniform float radius;
            uniform float distanceScale;
            varying vec2 vUv;

            void main() {
                vec2 center = blackHolePosition;
                vec2 pos = vUv - center;
                pos.x *= aspectRatio;

                float dist = length(pos);
                float scaledRadius = radius * distanceScale;
                
                // Core black hole region handling
                if (dist < scaledRadius * 1.2) {
                    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
                    return;
                }
                
                // Distortion effect implementation
                if (dist < scaledRadius * 8.0) {
                    float normDist = dist / scaledRadius;
                    float distortionFactor = 1.0 / pow(normDist, 1.5);
                    vec2 dir = normalize(pos);
                    float displacement = strength * distortionFactor * 0.8;
                    displacement *= 1.0 + pow(2.0 / max(normDist, 0.1), 2.0);
                    vec2 stretch = vec2(1.0, 1.2);
                    vec2 offset = dir * displacement * scaledRadius * stretch;
                    vec2 newUv = vUv - offset;
                    float edgeEffect = smoothstep(1.2, 3.0, normDist);
                    vec2 edgeOffset = dir * (1.0 - edgeEffect) * 0.1 * scaledRadius;
                    newUv -= edgeOffset;
                    gl_FragColor = texture2D(tDiffuse, newUv);
                    float blueShift = (1.0 - smoothstep(1.2, 2.0, normDist)) * 0.2;
                    gl_FragColor.b = mix(gl_FragColor.b, 1.0, blueShift);
                } else {
                    gl_FragColor = texture2D(tDiffuse, vUv);
                }
            }
        `;

        // Creating the shader material
        this.material = new THREE.ShaderMaterial({
            uniforms: this.uniforms,
            vertexShader: this.vertexShader,
            fragmentShader: this.fragmentShader
        });
    }

    // Handling black hole position updates
    updateBlackHolePosition(worldPosition, camera) {
        let vector = worldPosition.clone();
        vector.project(camera);
        
        this.uniforms.blackHolePosition.value.set(
            (vector.x + 1) / 2,
            (vector.y + 1) / 2
        );
    }

    // Managing aspect ratio changes
    updateAspectRatio(width, height) {
        this.uniforms.aspectRatio.value = width / height;
    }

    // Adjusting distortion strength
    setStrength(value) {
        this.uniforms.strength.value = value;
    }

    // Modifying effect radius
    setRadius(value) {
        this.uniforms.radius.value = value;
    }
}

export { LensingEffect };
